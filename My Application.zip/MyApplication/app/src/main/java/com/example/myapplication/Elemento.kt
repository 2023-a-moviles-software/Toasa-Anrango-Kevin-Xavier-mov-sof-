package com.example.myapplication

class Elemento (
    var nombreCombo: String,
    var promocionWhatssApp: String,
    var promocionRedesSociales: String,
    var promocionTikTok: String,
    var promocionMinIlimitados: String,
    var promocionTotal: String
        ) {

}